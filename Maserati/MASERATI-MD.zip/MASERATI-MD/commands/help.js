const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
*🤍⃝⃘̉̉̉━⋆─⋆─━──❂👑̉❂̉─⋆─⋆━🤍⃝⃘̉̉̉̉̉*
*┊ ┊ ┊ ┊ ┊┊ ┊ ┊ ┊ ┊┊ ┊┊ ┊*
*┊ ┊✫ ˚💎 ⋆｡ 👑┊ ┊✫ ˚💎 ⋆｡ 👑┊ ┊*
*┊ ✧                    ┊*
*✧  Royal𓂃👑𝄞*


╔══════✠══════╗
║     🏎️ *${settings.botName || '👑MASERAT-MD👑'}* 🏎️     ║
╠══════✠══════╣
║ 🛠️ Version: *${settings.version || '3.0.0'}*
║ 👤 Owner: *${settings.botOwner || 'yankeedev'}*
║ 📺 YT: ${global.ytch}
╠══════✠══════╣

║  💫 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 💫
╠══════❖══════╣

╔═══〔 🌐 𝐆É𝐍É𝐑𝐀𝐋 〕═══╗
║ 👑 .help | .ping
║ 👑 .alive | .tts
║ 👑 .owner | .quote
║ 👑 .weather | .news
║ 👑 .attp | .lyrics
║ 👑 .8ball | .groupinfo
║ 👑 .staff | .vv
║ 👑 .trt | .ss | .jid
║ 👑 .url
╚═══════════════╝

╔═〔 👮 𝐀𝐃𝐌𝐈𝐍𝐈𝐒𝐓𝐑𝐀𝐓𝐈𝐎𝐍 〕══╗
║ ⚜️ .ban | .kick
║ ⚜️ .warn | .promote
║ ⚜️ .demote | .mute
║ ⚜️ .unmute | .delete
║ ⚜️ .clear | .tagall
║ ⚜️ .hidetag | .antilink
║ ⚜️ .antibadword
║ ⚜️ .welcome | .goodbye
║ ⚜️ .setgname | .setgpp
╚═══════════════╝

╔═══〔 🔒 𝐏𝐑𝐎𝐏𝐑𝐈É𝐓𝐀𝐈𝐑𝐄 〕═══╗
║ 💎 .mode
║ 💎 .clearsession
║ 💎 .cleartmp | .update
║ 💎 .settings
║ 💎 .autostatus
║ 💎 .autoread | .anticall
║ 💎 .pmblocker | .setpp
║ 💎 .setmention
╚═══════════════╝

╔═══〔 🎨 𝐂𝐑É𝐀𝐓𝐈𝐎𝐍 〕═══╗
║ ✨ .sticker | .simage
║ ✨ .remini | .removebg
║ ✨ .blur | .crop
║ ✨ .meme | .take
║ ✨ .emojimix | .igs
║ ✨ .igsc
╚═══════════════╝

╔═══〔 🤖 𝐈𝐍𝐓𝐄𝐋𝐋𝐈𝐆𝐄𝐍𝐂𝐄 〕═══╗
║ 🧠 .gpt | .gemini
║ 🖼️ .imagine | .flux
║ 🖼️ .sora
║ ♟️ .tictactoe
║ ♟️ .hangman | .trivia
║ ♟️ .truth | .dare
╚═══════════════╝

╔═〔 📥 𝐓É𝐋É𝐂𝐇𝐀𝐑𝐆𝐄𝐌𝐄𝐍𝐓 〕═╗
║ 💫 .play | .song
║ 💫 .video | .spotify
║ 💫 .ytmp4 | .instagram
║ 💫 .facebook | .tiktok
╚══════════════╝

╔══〔 🔤 𝐓𝐘𝐏𝐎𝐆𝐑𝐀𝐏𝐇𝐈𝐄 〕═══╗
║ ✒️ .neon | .glitch
║ ✒️ .fire | .ice
║ ✒️ .snow | .matrix
║ ✒️ .hacker | .devil
║ ✒️ .sand
╚═══════════════╝

╔═══〔 💻 𝐒𝐘𝐒𝐓È𝐌𝐄 〕═══╗
║ ⚙️ .git | .github
║ ⚙️ .sc | .repo
║ ⚙️ .script
╚══════════════╝

╔══════❖══════╗
║ 💎 𝐋𝐮𝐱𝐞 • 𝐏𝐫𝐞𝐬𝐭𝐢𝐠𝐞 💎
║ 👑 𝐄𝐝𝐢𝐭𝐢𝐨𝐧 𝐑𝐨𝐲𝐚𝐥𝐞 👑
╚══════❖══════╝

*🤍⃝⃘̉̉̉━⋆─⋆─━──❂💎̉❂̉─⋆─⋆━🤍⃝⃘̉̉̉̉̉*
*┊ ┊ ┊ ┊ ┊┊ ┊ ┊ ┊ ┊┊ ┊┊ ┊*
*┊ ┊✫ ˚👑 ⋆｡ 💎┊ ┊✫ ˚👑 ⋆｡ 💎┊ ┊*
*┊ ⚜️              ⚜️ ┊*
*✧  𝐇𝐚𝐮𝐭𝐞 𝐂𝐨𝐮𝐭𝐮𝐫𝐞 ✧*
> BY YANKEE TECH
*Join our channel for updates:*`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        const contextInfo = {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363422011238396@newsletter',
                newsletterName: 'MASERATI MD',
                serverMessageId: -1
            }
        };

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;
